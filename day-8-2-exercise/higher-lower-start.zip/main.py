from game_data import data
from art import logo,vs
import random
from replit import clear
game_finish = False 
score = 0
pick_up_again = True

#rastgele seçim
print(logo)
print("Welcome to Higher Lower game \n")
while not game_finish:
    if pick_up_again:
        x = random.choice(data)
   
    print(
        f"Compare A: {x['name']}, a {x['description']},from {data[0]['country']}")
    print(vs)
    y = random.choice(data)
    if x == y:
        y = random.choice(data)
    print(
        f"Compare B: {y['name']}, a {y['description']},from {data[0]['country']}\n")
    #karar mercisi
    seçim = input("Which one has more follower on Instagram ('A' or 'B') ? ")    

    #A BÜYÜK VE DOĞRU 
    if seçim == "a" or seçim == "A" and int(x['follower_count']) > int(y['follower_count']):
        score += 1
        clear()
        print(f"Your score is {score}.")
        pick_up_again = False
        
        
        
        


     #B BÜYÜK VE DOĞRU   
    elif seçim == "b" or seçim == "B" and int(y['follower_count']) > int(x['follower_count']): 
        score += 1
        clear()
        print(f"Your score is {score}.")
        x = y
        pick_up_again = False

        
    # YANLIŞ CEVAP
    else:
        print(f"Thats not right 😭 Compare A has {x['follower_count']}M follower,Compare b has {y['follower_count']}M follower \nYour score is {score}\nGAME OVER ")
        game_finish = True